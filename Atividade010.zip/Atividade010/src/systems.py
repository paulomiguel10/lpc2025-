
from random import uniform
import pygame as pg
import config as C
from sprites import Ship, UFO, background
from utils import Vec
from sounds import sound_shot, zombie_sound, zombie_death, player_death


class World:

    def __init__(self):
        self.ship = Ship(Vec(C.WIDTH / 2, C.HEIGHT / 2))
        self.bullets = pg.sprite.Group()
        self.ufos = pg.sprite.Group()
        self.all_sprites = pg.sprite.Group(self.ship)

        self.ufo_timer = C.UFO_SPAWN_EVERY
        self.spawn_multiplier = 1  # Quantos zumbis nascem por vez
        self.difficulty_timer = 0  # Contador de tempo para aumentar dificul

        self.score = 0
        self.lives = C.START_LIVES
        self.safe = C.SAFE_SPAWN_TIME
        self.ufo_timer = C.UFO_SPAWN_EVERY

        self.buildings = [
            pg.Rect(45, 75, 190, 220),  # Prédio esquerdo
            pg.Rect(735, 330, 140, 250)  # Prédio direito
        ]

    def try_fire(self):
        bullet = self.ship.fire()
        if bullet:
            self.bullets.add(bullet)
            self.all_sprites.add(bullet)
        sound_shot.play()

    # Spawnar zombies
    def spawn_ufo(self):
        zombie_sound.play()
        side = uniform(0, 4)
        if side < 1:
            pos = Vec(0, uniform(0, C.HEIGHT))
        elif side < 2:
            pos = Vec(C.WIDTH, uniform(0, C.HEIGHT))
        elif side < 3:
            pos = Vec(uniform(0, C.WIDTH), 0)
        else:
            pos = Vec(uniform(0, C.WIDTH), C.HEIGHT)

        ufo = UFO(pos, self.ship)
        self.ufos.add(ufo)
        self.all_sprites.add(ufo)

    def update(self, dt: float, keys):
        self.ship.update(dt, keys)
        self.bullets.update(dt)
        self.ufos.update(dt)

        self.safe -= dt
        self.ufo_timer -= dt

        # Aumenta dificul
        self.difficulty_timer += dt

        if self.difficulty_timer >= 25:  # A cada 25 segundos
            self.difficulty_timer = 0

        # Aumenta quantos zumbis nascem por vez (máx 8)
            if self.spawn_multiplier < 8:
                self.spawn_multiplier += 1

        # Diminui o tempo entre spawns (mínimo 0.4s)
            C.UFO_SPAWN_EVERY = max(0.4, C.UFO_SPAWN_EVERY * 0.85)

    # SPAWN DE ZUMBIS
        if self.ufo_timer <= 0:
            for _ in range(self.spawn_multiplier):   # spawn múltiplo
                self.spawn_ufo()

            self.ufo_timer = C.UFO_SPAWN_EVERY

        # Colisão Player x Zombie
        if self.ship.invuln <= 0 and self.safe <= 0:
            for ufo in self.ufos:
                if (ufo.pos - self.ship.pos).length() < (ufo.r + self.ship.r):
                    player_death.play()
                    self.ship_die()
                    break

        # Colisão dos zumbis com as paredes
        for ufo in self.ufos:
            rect = ufo.rect
            for b in self.buildings:
                if rect.colliderect(b):
                    # Recuar movimento
                    ufo.pos -= ufo.dir * ufo.speed * dt
                    ufo.rect.center = ufo.pos
                    # Faz o zumbi andar pro outro lado
                    ufo.dir.rotate_ip(90)

        # Colisão ship com as paredes
        ship_rect = self.ship.rect
        for b in self.buildings:
            if ship_rect.colliderect(b):
                # Recuar o movimento do player
                self.ship.pos -= self.ship.vel * dt
                # Atualizar rect depois de mover a posição
                self.ship.rect.center = self.ship.pos
                # Para garantir que ele realmente pare
                self.ship.vel.xy = (0, 0)

        for ufo in list(self.ufos):
            for b in list(self.bullets):
                # Só balas da nave podem acertar o UFO
                if getattr(b, "owner", "ship") != "ship":
                    continue
                if (ufo.pos - b.pos).length() < (ufo.r + b.r):
                    self.score += C.UFO_SMALL["score"]
                    ufo.kill()
                    b.kill()
                    zombie_death.play()

    def ship_die(self):
        self.lives -= 1
        self.ship.pos.xy = (C.WIDTH / 2, C.HEIGHT / 2)
        self.ship.vel.xy = (0, 0)
        self.ship.angle = -90
        self.ship.invuln = C.SAFE_SPAWN_TIME
        self.safe = C.SAFE_SPAWN_TIME
        if self.lives < 0:
            # Reset total
            self.__init__()

    def draw(self, surf: pg.Surface, font: pg.font.Font):
        # Desenha o fundo primeiro
        surf.blit(background, (0, 0))
        for spr in self.all_sprites:
            spr.draw(surf)

        pg.draw.line(surf, (60, 60, 60), (0, 50), (C.WIDTH, 50), width=1)
        txt = f"SCORE {self.score:06d}   LIVES {self.lives}"
        label = font.render(txt, True, C.WHITE)
        surf.blit(label, (10, 10))
